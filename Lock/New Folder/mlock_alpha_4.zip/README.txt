How to use MassiveLock:
just run mlock_alpha_4.exe it's self explainitory.

How to compile source code:
What you need:
AutoIt V3(http://autoitscript.com)


To compile the source code if you have AutoIt V3 installed simple right clcik mlock_alpha_4.au3 and select compile script.